     Unpack, install the application.

     Extract patch_x86.rar to <installation folder>\Bin directory,
     overwriting existing files.

     If installing on x64 OS, extract patch_x64.rar to
     <installation folder>\BinX64 directory, overwriting existing files.

     Use our Keygen to generate a license certificate, and paste it in
     the application's license dialog.

     Disable automatic updates.


     NOTE:

     The patch only patches the RSA public key and the encrypted RC4 key.